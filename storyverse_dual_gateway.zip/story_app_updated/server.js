const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

// Optional dependency-free .env loader. Existing process environment always wins.
try {
  const envText = fs.readFileSync(path.join(__dirname, '.env'), 'utf8');
  for (const line of envText.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m || Object.prototype.hasOwnProperty.call(process.env, m[1])) continue;
    let value = m[2];
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    process.env[m[1]] = value;
  }
} catch { }

const PORT = 3000;
const ROOT = __dirname;
const STORY_DIR = path.join(ROOT, 'story');
const DATA_DIR = path.join(ROOT, 'data');   // data/<googleUserId>/<chatId>.json
const AUTH_DIR = path.join(ROOT, 'auth');   // sessions.json

// ===== GOOGLE LOGIN =====
// Isi dari Google Cloud Console → APIs & Services → Credentials → OAuth client ID (Web)
const GOOGLE_CLIENT_ID = '230132707860-e18s9hlga0039qrlme7s31lp41s8bf31.apps.googleusercontent.com';
// Kosongkan [] = semua akun Google boleh masuk. Isi untuk membatasi, mis. ['kamu@gmail.com']
const ALLOWED_EMAILS = [];
const SESSION_TTL = 30 * 24 * 3600 * 1000; // 30 hari

const LM_URL = 'http://localhost:1234/v1/chat/completions'; // fallback
const RUNPOD_URL = process.env.RUNPOD_URL || 'https://api.runpod.ai/v2/utstmcoe7bojem/openai/v1/chat/completions';
// false = tunggu jawaban penuh lalu simpan (stabil). true = teks tampil bertahap saat ditulis AI.
const STREAM = false;
// Model Qwen3.x punya mode "thinking". Kalau jawaban masih sering kosong, coba true.
const DISABLE_THINKING = false;
const RUNPOD_KEY = process.env.RUNPOD_KEY || '';

// ===== PAYMENT GATEWAYS =====
const APP_BASE_URL = (process.env.APP_BASE_URL || '').replace(/\/$/, '');
const XENDIT_SECRET_KEY = process.env.XENDIT_SECRET_KEY || '';
const XENDIT_CALLBACK_TOKEN = process.env.XENDIT_CALLBACK_TOKEN || '';
const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY || '';
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET || '';
const STRIPE_CURRENCY = (process.env.STRIPE_CURRENCY || 'usd').toLowerCase();
const SUBSCRIPTION_DAYS = 30;
const PAYMENT_PLANS = {
  coins_500:  { coins: 500,  label: '500 koin',      idr: Number(process.env.PRICE_COINS_500_IDR) || 0,  usd: Number(process.env.PRICE_COINS_500_USD) || 0 },
  coins_1500: { coins: 1500, label: '1.500 koin',    idr: Number(process.env.PRICE_COINS_1500_IDR) || 0, usd: Number(process.env.PRICE_COINS_1500_USD) || 0 },
  coins_5000: { coins: 5000, label: '5.000 koin',    idr: Number(process.env.PRICE_COINS_5000_IDR) || 0, usd: Number(process.env.PRICE_COINS_5000_USD) || 0 },
  subscription_monthly: { days: SUBSCRIPTION_DAYS, label: 'Unlimited 30 hari', idr: Number(process.env.PRICE_UNLIMITED_30D_IDR) || 0, usd: Number(process.env.PRICE_UNLIMITED_30D_USD) || 0 }
};
const RUNPOD_MODEL = 'Qwen3.5-9B-The-Defiant-Fable-Uncnr-Heretic-NEO-MAX-Q4_K_M';

function ensureDir(d) { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); }
ensureDir(STORY_DIR); ensureDir(DATA_DIR); ensureDir(AUTH_DIR);

const jobs = new Map(); // "<userId>:<chatId>" -> { partial }

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webp': 'image/webp', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml'
};

function json(res, status, obj) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let buf = '';
    req.on('data', c => buf += c);
    req.on('end', () => resolve(buf));
    req.on('error', reject);
  });
}
function safeId(id) { return /^[a-zA-Z0-9_-]+$/.test(id) ? id : null; }

// ===== SESSIONS =====
const SESS_FILE = path.join(AUTH_DIR, 'sessions.json');
let sessions = {};
try { sessions = JSON.parse(fs.readFileSync(SESS_FILE, 'utf8')); } catch { }
function saveSessions() { fs.writeFile(SESS_FILE, JSON.stringify(sessions), () => { }); }

function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
function getSession(req) {
  const sid = parseCookies(req).sid;
  const s = sid && sessions[sid];
  if (!s) return null;
  if (s.exp < Date.now()) { delete sessions[sid]; saveSessions(); return null; }
  return { sid, user: s.user };
}
function setCookie(res, sid, maxAgeSec) {
  // Kalau nanti pakai HTTPS, tambahkan "; Secure"
  res.setHeader('Set-Cookie', `sid=${sid}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAgeSec}`);
}

async function verifyGoogle(credential) {
  const r = await fetch('https://oauth2.googleapis.com/tokeninfo?id_token=' + encodeURIComponent(credential));
  if (!r.ok) throw new Error('Token Google tidak valid');
  const t = await r.json();
  if (t.aud !== GOOGLE_CLIENT_ID) throw new Error('Client ID tidak cocok');
  if (!['accounts.google.com', 'https://accounts.google.com'].includes(t.iss)) throw new Error('Issuer salah');
  if (String(t.email_verified) !== 'true') throw new Error('Email belum terverifikasi');
  if (!safeId(String(t.sub))) throw new Error('ID user tidak valid');
  if (ALLOWED_EMAILS.length && !ALLOWED_EMAILS.includes(t.email)) throw new Error('Akun ini tidak diizinkan');
  return { sub: String(t.sub), email: t.email, name: t.name || t.email, picture: t.picture || '' };
}

// ===== PER-USER DATA =====
function userDir(user) {
  const d = path.join(DATA_DIR, user.sub);
  ensureDir(d);
  return d;
}

// ===== WALLET =====
const AI_REPLY_COST = 30;
const INITIAL_COINS = Math.max(0, Number(process.env.INITIAL_COINS) || 0);
function walletFile(user) { return path.join(userDir(user), 'wallet.json'); }
function readWallet(user) {
  const file = walletFile(user);
  let wallet;
  try { wallet = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { wallet = { coins: INITIAL_COINS, subscriptionUntil: 0 }; }
  wallet.coins = Math.max(0, Number(wallet.coins) || 0);
  wallet.subscriptionUntil = Number(wallet.subscriptionUntil) || 0;
  wallet.processedOrders = Array.isArray(wallet.processedOrders) ? wallet.processedOrders : [];
  return wallet;
}
function writeWallet(user, wallet) {
  fs.writeFileSync(walletFile(user), JSON.stringify(wallet, null, 2), 'utf8');
}
function hasUnlimited(wallet) { return wallet.subscriptionUntil > Date.now(); }

// ===== PAYMENT ORDER HELPERS =====
function orderFile(user, orderId) { return path.join(userDir(user), 'order_' + orderId + '.json'); }
function findOrderById(orderId) {
  if (!/^[a-f0-9-]{20,80}$/i.test(String(orderId || ''))) return null;
  const dirs = fs.readdirSync(DATA_DIR, { withFileTypes: true }).filter(x => x.isDirectory());
  for (const d of dirs) {
    const f = path.join(DATA_DIR, d.name, 'order_' + orderId + '.json');
    try { return { file: f, order: JSON.parse(fs.readFileSync(f, 'utf8')) }; } catch { }
  }
  return null;
}
function saveOrder(file, order) { fs.writeFileSync(file, JSON.stringify(order, null, 2), 'utf8'); }
function creditPaidOrder(file, order) {
  if (order.status === 'paid') return false;
  const wallet = readWallet({ sub: order.userId });
  if (wallet.processedOrders.includes(order.id)) { order.status = 'paid'; order.paidAt = order.paidAt || Date.now(); saveOrder(file, order); return false; }
  if (order.plan === 'subscription_monthly') {
    wallet.subscriptionUntil = Math.max(Date.now(), wallet.subscriptionUntil) + order.days * 24 * 60 * 60 * 1000;
  } else {
    wallet.coins += order.coins;
  }
  wallet.processedOrders.push(order.id);
  writeWallet({ sub: order.userId }, wallet);
  order.status = 'paid'; order.paidAt = Date.now(); saveOrder(file, order);
  return true;
}
function amountFor(plan, currency) {
  const p = PAYMENT_PLANS[plan];
  if (!p) return 0;
  return currency === 'IDR' ? p.idr : p.usd;
}
function appUrl(pathname) {
  if (!APP_BASE_URL) throw new Error('APP_BASE_URL belum diatur. Gunakan URL publik HTTPS aplikasi.');
  return APP_BASE_URL + pathname;
}
async function createXenditSession(order, user, amount) {
  const displayName = String(user.name || user.email || 'StoryVerse User').trim().split(/\s+/);
  const payload = {
    reference_id: order.id,
    session_type: 'PAY',
    mode: 'PAYMENT_LINK',
    amount,
    currency: 'IDR',
    country: 'ID',
    customer: {
      reference_id: user.sub,
      type: 'INDIVIDUAL',
      email: user.email,
      individual_detail: { given_names: displayName[0] || 'StoryVerse', surname: displayName.slice(1).join(' ') || undefined }
    },
    description: 'StoryVerse - ' + order.label,
    capture_method: 'AUTOMATIC',
    success_return_url: appUrl('/shop.html?payment=processing'),
    cancel_return_url: appUrl('/shop.html?payment=cancelled')
    // Omit allowed_payment_channels so hosted checkout displays channels enabled for this merchant.
  };
  const r = await fetch('https://api.xendit.co/sessions', {
    method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Basic ' + Buffer.from(XENDIT_SECRET_KEY + ':').toString('base64') },
    body: JSON.stringify(payload)
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.message || data.error_code || 'Xendit gagal membuat payment session');
  if (!data.payment_link_url || !data.payment_session_id) throw new Error('Respons Xendit tidak memiliki payment_link_url/session_id');
  return { url: data.payment_link_url, sessionId: data.payment_session_id };
}
async function getXenditSession(sessionId) {
  const r = await fetch('https://api.xendit.co/sessions/' + encodeURIComponent(sessionId), {
    headers: { 'Authorization': 'Basic ' + Buffer.from(XENDIT_SECRET_KEY + ':').toString('base64') }
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.message || 'Tidak dapat memverifikasi Xendit session');
  return data;
}
async function createStripeCheckout(order, user, amount) {
  const params = new URLSearchParams();
  params.set('mode', 'payment');
  params.set('success_url', appUrl('/shop.html?payment=processing&session_id={CHECKOUT_SESSION_ID}'));
  params.set('cancel_url', appUrl('/shop.html?payment=cancelled'));
  params.set('customer_email', user.email);
  params.set('client_reference_id', order.id);
  params.set('line_items[0][price_data][currency]', STRIPE_CURRENCY);
  params.set('line_items[0][price_data][unit_amount]', String(Math.round(amount * 100)));
  params.set('line_items[0][price_data][product_data][name]', 'StoryVerse - ' + order.label);
  params.set('line_items[0][quantity]', '1');
  params.set('metadata[order_id]', order.id);
  params.set('metadata[user_id]', order.userId);
  params.set('metadata[plan]', order.plan);
  const r = await fetch('https://api.stripe.com/v1/checkout/sessions', {
    method: 'POST', headers: { 'Authorization': 'Bearer ' + STRIPE_SECRET_KEY, 'Content-Type': 'application/x-www-form-urlencoded' }, body: params
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error?.message || 'Stripe gagal membuat checkout');
  return data.url;
}
function verifyStripeSignature(raw, header) {
  if (!STRIPE_WEBHOOK_SECRET || !header) return false;
  const parts = Object.fromEntries(header.split(',').map(x => x.split('=')));
  const timestamp = parts.t;
  if (!timestamp || Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) return false;
  const expected = crypto.createHmac('sha256', STRIPE_WEBHOOK_SECRET).update(timestamp + '.' + raw).digest('hex');
  return (header.match(/v1=([a-f0-9]+)/g) || []).some(x => {
    const received = x.slice(3);
    return received.length === expected.length && crypto.timingSafeEqual(Buffer.from(received), Buffer.from(expected));
  });
}

// Chat lama (data/*.json tanpa folder user) dipindah ke user PERTAMA yang login.
async function migrateLegacy(user) {
  const entries = await fsp.readdir(DATA_DIR, { withFileTypes: true }).catch(() => []);
  const hasUserDirs = entries.some(e => e.isDirectory());
  const legacy = entries.filter(e => e.isFile() && e.name.endsWith('.json'));
  if (hasUserDirs || legacy.length === 0) return;
  const dir = userDir(user);
  for (const f of legacy) await fsp.rename(path.join(DATA_DIR, f.name), path.join(dir, f.name));
  console.log(`[migrate] ${legacy.length} chat lama dipindah ke user ${user.email}`);
}

// ===== BACKGROUND GENERATE =====
// Buang blok <think>...</think> kalau bocor ke dalam content
function cleanThink(t) {
  t = String(t || '').replace(/<think>[\s\S]*?<\/think>/g, '');
  const i = t.lastIndexOf('</think>');
  if (i >= 0) t = t.slice(i + 8);
  return t.replace(/<\/?think>/g, '').trim();
}

async function runJob(key, file, job, body) {
  let reply = '';
  try {
    if (!RUNPOD_KEY) throw new Error('RUNPOD_KEY belum diatur di environment server');
    const payload = {
      model: body.model || RUNPOD_MODEL,
      messages: body.messages,
      max_tokens: body.max_tokens ?? 2000,
      temperature: body.temperature ?? 0.85,
      stream: false
    };
    if (DISABLE_THINKING) payload.chat_template_kwargs = { enable_thinking: false };

    const upstream = await fetch(RUNPOD_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + RUNPOD_KEY },
      body: JSON.stringify(payload)
    });
    if (!upstream.ok) {
      const t = await upstream.text().catch(() => '');
      throw new Error(`RunPod ${upstream.status}: ${t.slice(0, 300)}`);
    }

    let content = '', reasoning = '', finish = null;

    if (!STREAM) {
      // ---- Non-stream: satu blok JSON ----
      const raw = await upstream.text();
      let j;
      try { j = JSON.parse(raw); }
      catch { throw new Error('Balasan RunPod bukan JSON: ' + raw.slice(0, 200)); }
      if (j.error) throw new Error('RunPod: ' + (j.error.message || JSON.stringify(j.error)).slice(0, 300));
      const ch = j.choices?.[0];
      finish = ch?.finish_reason ?? null;
      content = ch?.message?.content || '';
      reasoning = ch?.message?.reasoning_content || ch?.message?.reasoning || '';
    } else {
      // ---- Stream: SSE "data: {...}" ----
      const reader = upstream.body.getReader();
      const dec = new TextDecoder();
      let buf = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        const lines = buf.split('\n');
        buf = lines.pop() ?? '';
        for (const line of lines) {
          if (!line.startsWith('data:')) continue;
          const d = line.slice(5).trim();
          if (!d || d === '[DONE]') continue;
          try {
            const ch = JSON.parse(d).choices?.[0];
            if (ch?.finish_reason) finish = ch.finish_reason;
            const dl = ch?.delta || {};
            if (dl.content) { content += dl.content; job.partial = cleanThink(content); }
            const rc = dl.reasoning_content ?? dl.reasoning;
            if (rc) reasoning += rc;
          } catch { }
        }
      }
    }

    let final = cleanThink(content);
    console.log(`[job ${key}] stream=${STREAM} content=${content.length} reasoning=${reasoning.length} finish=${finish}`);
    if (!final && reasoning.trim()) {
      console.warn(`[job ${key}] content kosong, pakai reasoning_content sebagai jawaban`);
      final = cleanThink(reasoning);
    }
    if (!final) throw new Error(`Empty AI output (content=${content.length}, reasoning=${reasoning.length} karakter, finish=${finish})`);
    reply = final;
  } catch (e) {
    reply = 'Error: ' + (e.message || e);
    console.error(`[job ${key}]`, e.message || e);
  }

  // Biaya hanya final jika AI berhasil memberi jawaban. Kegagalan mengembalikan reservasi.
  if (job.reserved && reply.startsWith('Error: ')) {
    const wallet = readWallet(job.user);
    wallet.coins += AI_REPLY_COST;
    writeWallet(job.user, wallet);
  }
  try {
    const chat = JSON.parse(await fsp.readFile(file, 'utf8'));
    chat.messages.push({ role: 'assistant', content: reply });
    chat.updatedAt = Date.now();
    await fsp.writeFile(file, JSON.stringify(chat, null, 2), 'utf8');
  } catch (e) { console.error('[JOB save]', e); }
  jobs.delete(key);
}

// File/folder yang TIDAK boleh diakses lewat static server
const BLOCKED_TOP = new Set(['data', 'story', 'auth', 'node_modules']);
const BLOCKED_FILES = new Set(['server.js', 'package.json', 'package-lock.json']);

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  const p = url.pathname;

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,DELETE,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); return res.end(); }

  try {
    // ===== PAYMENT WEBHOOKS (publik, wajib verifikasi signature/token) =====
    if (p === '/api/webhooks/xendit' && req.method === 'POST') {
      const raw = await readBody(req);
      if (!XENDIT_CALLBACK_TOKEN || req.headers['x-callback-token'] !== XENDIT_CALLBACK_TOKEN) return json(res, 401, { error: 'invalid callback token' });
      const event = JSON.parse(raw);
      const data = event.data || {};
      const eventName = String(event.event || '').toLowerCase();
      const orderId = data.reference_id || event.reference_id;
      const found = findOrderById(orderId);
      if (!found) return json(res, 404, { error: 'order not found' });
      if (found.order.provider !== 'xendit') return json(res, 400, { error: 'provider mismatch' });
      if (eventName.includes('expired') || String(data.status || '').toUpperCase() === 'EXPIRED') {
        found.order.status = 'expired'; saveOrder(found.file, found.order);
        return json(res, 200, { ok: true });
      }
      if (eventName.includes('completed') || String(data.status || '').toUpperCase() === 'COMPLETED') {
        const sessionId = data.payment_session_id || data.id || found.order.xenditSessionId;
        if (!sessionId || !XENDIT_SECRET_KEY) return json(res, 400, { error: 'missing session id or API key' });
        const verified = await getXenditSession(sessionId);
        if (verified.reference_id === found.order.id && String(verified.status).toUpperCase() === 'COMPLETED' && Number(verified.amount) === found.order.amount && String(verified.currency).toUpperCase() === 'IDR' && verified.payment_id) {
          creditPaidOrder(found.file, found.order);
        }
      }
      return json(res, 200, { ok: true });
    }
    if (p === '/api/webhooks/stripe' && req.method === 'POST') {
      const raw = await readBody(req);
      if (!verifyStripeSignature(raw, req.headers['stripe-signature'])) return json(res, 400, { error: 'invalid Stripe signature' });
      const event = JSON.parse(raw);
      if (event.type === 'checkout.session.completed' || event.type === 'checkout.session.async_payment_succeeded') {
        const session = event.data?.object;
        if (session?.payment_status === 'paid') {
          const found = findOrderById(session.metadata?.order_id || session.client_reference_id);
          if (found && found.order.provider === 'stripe' && session.metadata?.user_id === found.order.userId && session.metadata?.plan === found.order.plan && Number(session.amount_total) === found.order.amountMinor && String(session.currency).toLowerCase() === found.order.currency.toLowerCase()) creditPaidOrder(found.file, found.order);
        }
      }
      return json(res, 200, { received: true });
    }

    // ===== AUTH (publik) =====
    if (p === '/api/auth/config' && req.method === 'GET') {
      return json(res, 200, { clientId: GOOGLE_CLIENT_ID });
    }
    if (p === '/api/auth/google' && req.method === 'POST') {
      const { credential } = JSON.parse(await readBody(req));
      if (!credential) return json(res, 400, { error: 'credential kosong' });
      let user;
      try { user = await verifyGoogle(credential); }
      catch (e) { return json(res, 401, { error: e.message }); }
      await migrateLegacy(user);
      userDir(user);
      const sid = crypto.randomBytes(32).toString('hex');
      sessions[sid] = { user, exp: Date.now() + SESSION_TTL };
      saveSessions();
      setCookie(res, sid, SESSION_TTL / 1000);
      return json(res, 200, { ok: true, user });
    }
    if (p === '/api/auth/logout' && req.method === 'POST') {
      const s = getSession(req);
      if (s) { delete sessions[s.sid]; saveSessions(); }
      setCookie(res, '', 0);
      return json(res, 200, { ok: true });
    }

    // ===== SEMUA /api LAINNYA WAJIB LOGIN =====
    let user = null;
    if (p.startsWith('/api/')) {
      const s = getSession(req);
      if (!s) return json(res, 401, { error: 'unauthorized' });
      user = s.user;
    }

    if (p === '/api/me' && req.method === 'GET') return json(res, 200, user);

    if (p === '/api/wallet' && req.method === 'GET') {
      const wallet = readWallet(user);
      return json(res, 200, { coins: wallet.coins, subscriptionUntil: wallet.subscriptionUntil, unlimited: hasUnlimited(wallet), replyCost: AI_REPLY_COST });
    }
    if (p === '/api/shop/config' && req.method === 'GET') {
      const plans = Object.entries(PAYMENT_PLANS).map(([id, plan]) => ({ id, label: plan.label, coins: plan.coins || 0, days: plan.days || 0, idr: plan.idr || null, usd: plan.usd || null }));
      return json(res, 200, { plans, gateways: { xendit: !!(XENDIT_SECRET_KEY && XENDIT_CALLBACK_TOKEN), stripe: !!(STRIPE_SECRET_KEY && STRIPE_WEBHOOK_SECRET) }, stripeCurrency: STRIPE_CURRENCY.toUpperCase() });
    }
    if (p === '/api/shop/checkout' && req.method === 'POST') {
      const body = JSON.parse(await readBody(req));
      const plan = PAYMENT_PLANS[body.plan];
      const provider = String(body.provider || '').toLowerCase();
      if (!plan || !['xendit', 'stripe'].includes(provider)) return json(res, 400, { error: 'Paket atau metode pembayaran tidak valid.' });
      if (!APP_BASE_URL) return json(res, 503, { error: 'APP_BASE_URL belum dikonfigurasi.' });
      const currency = provider === 'xendit' ? 'IDR' : STRIPE_CURRENCY.toUpperCase();
      const amount = amountFor(body.plan, currency);
      if (!amount || !Number.isFinite(amount) || amount <= 0) return json(res, 503, { error: `Harga ${plan.label} untuk ${currency} belum diatur di environment server.` });
      if (provider === 'xendit' && (!XENDIT_SECRET_KEY || !XENDIT_CALLBACK_TOKEN)) return json(res, 503, { error: 'Xendit belum siap. Atur XENDIT_SECRET_KEY dan XENDIT_CALLBACK_TOKEN.' });
      if (provider === 'stripe' && (!STRIPE_SECRET_KEY || !STRIPE_WEBHOOK_SECRET)) return json(res, 503, { error: 'Stripe belum siap. Atur STRIPE_SECRET_KEY dan STRIPE_WEBHOOK_SECRET dari akun Stripe yang eligible.' });
      const id = crypto.randomUUID();
      const order = { id, userId: user.sub, email: user.email, plan: body.plan, label: plan.label, coins: plan.coins || 0, days: plan.days || 0, provider, currency, amount, amountMinor: provider === 'stripe' ? Math.round(amount * 100) : amount, status: 'pending', createdAt: Date.now() };
      const file = orderFile(user, id); saveOrder(file, order);
      try {
        let checkoutUrl;
        if (provider === 'xendit') {
          const session = await createXenditSession(order, user, amount);
          checkoutUrl = session.url; order.xenditSessionId = session.sessionId;
        } else checkoutUrl = await createStripeCheckout(order, user, amount);
        order.checkoutUrl = checkoutUrl; saveOrder(file, order);
        return json(res, 200, { ok: true, checkoutUrl, orderId: id, provider, currency, amount });
      } catch (e) {
        order.status = 'failed'; order.error = String(e.message || e).slice(0, 300); saveOrder(file, order);
        return json(res, 502, { error: order.error });
      }
    }
    if (p === '/api/shop/orders' && req.method === 'GET') {
      const files = await fsp.readdir(userDir(user)).catch(() => []);
      const orders = [];
      for (const f of files.filter(x => /^order_[a-f0-9-]+\.json$/i.test(x))) {
        try { const o = JSON.parse(await fsp.readFile(path.join(userDir(user), f), 'utf8')); orders.push({ id: o.id, plan: o.plan, label: o.label, provider: o.provider, currency: o.currency, amount: o.amount, status: o.status, createdAt: o.createdAt }); } catch { }
      }
      orders.sort((a,b) => b.createdAt-a.createdAt);
      return json(res, 200, orders);
    }

    // ===== STORIES (dibaca semua user; hanya pemilik yang boleh ubah/hapus) =====
    if (p === '/api/stories' && req.method === 'GET') {
      const files = await fsp.readdir(STORY_DIR).catch(() => []);
      const list = [];
      for (const f of files) {
        if (!f.endsWith('.json')) continue;
        try { list.push(JSON.parse(await fsp.readFile(path.join(STORY_DIR, f), 'utf8'))); } catch { }
      }
      list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      return json(res, 200, list);
    }
    if (p === '/api/stories' && req.method === 'POST') {
      const body = JSON.parse(await readBody(req));
      if (!body.id || !safeId(body.id)) return json(res, 400, { error: 'invalid id' });
      const file = path.join(STORY_DIR, body.id + '.json');
      let existing = null;
      try { existing = JSON.parse(await fsp.readFile(file, 'utf8')); } catch { }
      if (existing?.ownerId && existing.ownerId !== user.sub)
        return json(res, 403, { error: 'Cerita ini milik user lain' });
      body.ownerId = existing?.ownerId || user.sub;
      body.updatedAt = Date.now();
      if (!body.createdAt) body.createdAt = existing?.createdAt || body.updatedAt;
      await fsp.writeFile(file, JSON.stringify(body, null, 2), 'utf8');
      return json(res, 200, body);
    }

    let m = p.match(/^\/api\/stories\/([^/]+)$/);
    if (m) {
      const id = safeId(m[1]); if (!id) return json(res, 400, { error: 'invalid id' });
      const file = path.join(STORY_DIR, id + '.json');
      if (req.method === 'GET') {
        try { return json(res, 200, JSON.parse(await fsp.readFile(file, 'utf8'))); }
        catch { return json(res, 404, { error: 'not found' }); }
      }
      if (req.method === 'DELETE') {
        try {
          const st = JSON.parse(await fsp.readFile(file, 'utf8'));
          if (st.ownerId && st.ownerId !== user.sub)
            return json(res, 403, { error: 'Cerita ini milik user lain' });
        } catch { }
        try { await fsp.unlink(file); } catch { }
        // hapus chat terkait milik SEMUA user
        const dirs = await fsp.readdir(DATA_DIR, { withFileTypes: true }).catch(() => []);
        for (const d of dirs) {
          if (!d.isDirectory()) continue;
          const dp = path.join(DATA_DIR, d.name);
          for (const cf of await fsp.readdir(dp).catch(() => [])) {
            if (!cf.endsWith('.json')) continue;
            try {
              const c = JSON.parse(await fsp.readFile(path.join(dp, cf), 'utf8'));
              if (c.storyId === id) await fsp.unlink(path.join(dp, cf));
            } catch { }
          }
        }
        return json(res, 200, { ok: true });
      }
    }

    // ===== CHATS (per user) =====
    if (p === '/api/chats' && req.method === 'GET') {
      const dir = userDir(user);
      const storyId = url.searchParams.get('story');
      const files = await fsp.readdir(dir).catch(() => []);
      const list = [];
      for (const f of files) {
        if (!f.endsWith('.json') || f === 'wallet.json') continue;
        try {
          const c = JSON.parse(await fsp.readFile(path.join(dir, f), 'utf8'));
          if (!storyId || c.storyId === storyId) list.push(c);
        } catch { }
      }
      list.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
      const summary = list.map(c => ({
        id: c.id, storyId: c.storyId, title: c.title,
        messageCount: c.messages?.length || 0,
        createdAt: c.createdAt, updatedAt: c.updatedAt
      }));
      return json(res, 200, summary);
    }

    if (p === '/api/chats' && req.method === 'POST') {
      const body = JSON.parse(await readBody(req));
      if (!body.id || !safeId(body.id)) return json(res, 400, { error: 'invalid id' });
      body.updatedAt = Date.now();
      if (!body.createdAt) body.createdAt = body.updatedAt;
      await fsp.writeFile(path.join(userDir(user), body.id + '.json'), JSON.stringify(body, null, 2), 'utf8');
      return json(res, 200, body);
    }

    m = p.match(/^\/api\/chats\/([^/]+)$/);
    if (m) {
      const id = safeId(m[1]); if (!id) return json(res, 400, { error: 'invalid id' });
      const file = path.join(userDir(user), id + '.json');
      if (req.method === 'GET') {
        try { return json(res, 200, JSON.parse(await fsp.readFile(file, 'utf8'))); }
        catch { return json(res, 404, { error: 'not found' }); }
      }
      if (req.method === 'POST' || req.method === 'PUT') {
        const body = JSON.parse(await readBody(req));
        body.id = id; body.updatedAt = Date.now();
        if (!body.createdAt) body.createdAt = body.updatedAt;
        await fsp.writeFile(file, JSON.stringify(body, null, 2), 'utf8');
        return json(res, 200, body);
      }
      if (req.method === 'DELETE') {
        try { await fsp.unlink(file); } catch { }
        return json(res, 200, { ok: true });
      }
    }

    // ===== BACKGROUND GENERATE (per user) =====
    m = p.match(/^\/api\/chats\/([^/]+)\/(generate|status)$/);
    if (m) {
      const id = safeId(m[1]); if (!id) return json(res, 400, { error: 'invalid id' });
      const file = path.join(userDir(user), id + '.json');
      const key = user.sub + ':' + id;
      if (m[2] === 'status' && req.method === 'GET') {
        const job = jobs.get(key);
        return json(res, 200, { generating: !!job, partial: job?.partial || '' });
      }
      if (m[2] === 'generate' && req.method === 'POST') {
        if (!fs.existsSync(file)) return json(res, 404, { error: 'chat tidak ditemukan' });
        if (jobs.has(key)) return json(res, 409, { error: 'sedang generate' });
        const body = JSON.parse(await readBody(req));
        const wallet = readWallet(user);
        const unlimited = hasUnlimited(wallet);
        if (!unlimited && wallet.coins < AI_REPLY_COST) {
          return json(res, 402, { error: `Koin tidak cukup. Satu jawaban AI membutuhkan ${AI_REPLY_COST} koin.`, coins: wallet.coins, required: AI_REPLY_COST });
        }
        // Reservasi dilakukan sinkron agar dua request bersamaan tidak memakai saldo yang sama.
        if (!unlimited) { wallet.coins -= AI_REPLY_COST; writeWallet(user, wallet); }
        const job = { partial: '', reserved: !unlimited, user };
        jobs.set(key, job);
        runJob(key, file, job, body); // background, tanpa await
        return json(res, 200, { started: true });
      }
    }

    // ===== CHAT PROXY (lama, sekarang wajib login) =====
    if (p === '/api/chat' && req.method === 'POST') {
      const body = JSON.parse(await readBody(req));
      const payload = {
        model: body.model || RUNPOD_MODEL,
        messages: body.messages,
        max_tokens: body.max_tokens ?? 2000,
        temperature: body.temperature ?? 0.85,
        stream: !!body.stream
      };
      const upstream = await fetch(RUNPOD_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + RUNPOD_KEY },
        body: JSON.stringify(payload)
      });
      if (!upstream.ok) {
        const t = await upstream.text().catch(() => '');
        return json(res, 502, { error: `RunPod ${upstream.status}: ${t.slice(0, 300)}` });
      }
      if (payload.stream) {
        res.writeHead(200, {
          'Content-Type': 'text/event-stream; charset=utf-8',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive'
        });
        const reader = upstream.body.getReader();
        const dec = new TextDecoder();
        try {
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            res.write(dec.decode(value, { stream: true }));
          }
        } finally { res.end(); }
        return;
      }
      return json(res, 200, await upstream.json());
    }

    if (p.startsWith('/api/')) return json(res, 404, { error: 'not found' });

    // ===== STATIC =====
    let fp = p === '/' ? '/index.html' : p;
    const resolved = path.normalize(path.join(ROOT, fp));
    if (!resolved.startsWith(ROOT)) { res.writeHead(403); return res.end('Forbidden'); }
    const rel = path.relative(ROOT, resolved);
    const top = rel.split(path.sep)[0];
    if (BLOCKED_TOP.has(top) || BLOCKED_FILES.has(rel) || rel.split(path.sep).some(s => s.startsWith('.'))) {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      return res.end('Not found: ' + fp);
    }
    try {
      const st = await fsp.stat(resolved);
      if (st.isDirectory()) { res.writeHead(403); return res.end('Forbidden'); }
      const ext = path.extname(resolved).toLowerCase();
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'application/octet-stream' });
      fs.createReadStream(resolved).pipe(res);
    } catch {
      res.writeHead(404, { 'Content-Type': 'text/plain' });
      res.end('Not found: ' + fp);
    }
  } catch (e) {
    console.error('[ERR]', e);
    if (!res.headersSent) json(res, 500, { error: String(e.message || e) });
    else res.end();
  }
});

server.listen(PORT, () => {
  console.log(`🚀 http://localhost:${PORT}`);
  console.log(`   story/  ← ${STORY_DIR}`);
  console.log(`   data/   ← ${DATA_DIR}  (per user)`);
});
