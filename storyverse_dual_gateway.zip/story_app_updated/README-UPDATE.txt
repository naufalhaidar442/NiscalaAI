# StoryVerse — versi update

## Fitur aplikasi
- Katalog cerita dengan pencarian judul/deskripsi dan filter genre.
- Genre cerita dapat diisi saat membuat atau mengedit cerita.
- Halaman detail cerita, karakter, opening message, dan riwayat chat per cerita.
- Sidebar: Discover, Riwayat Chat, Shop, Setting, Account.
- Wallet per akun dan biaya 30 koin untuk setiap jawaban AI yang berhasil.
- Jika proses AI gagal, reservasi 30 koin dikembalikan.
- Shop dual gateway: Xendit untuk pembayaran IDR/Indonesia dan Stripe Checkout untuk pelanggan internasional.
- Paket Unlimited adalah pembelian satu kali untuk 30 hari, tanpa auto-renew.
- Saldo/masa Unlimited hanya dikreditkan setelah webhook provider diverifikasi server; pemrosesan order idempotent.

## Menjalankan
Gunakan Node.js 18+ (agar tersedia fetch bawaan). Salin `.env.example` menjadi `.env` dan masukkan nilai environment pada hosting/server. Jangan commit `.env` atau mengirim secret key ke browser.

Contoh Linux/macOS:
```bash
export APP_BASE_URL="https://domain-aplikasi-kamu"
export RUNPOD_KEY="API_KEY_RUNPOD_BARU"
export XENDIT_SECRET_KEY="xnd_development_..."
export XENDIT_CALLBACK_TOKEN="token_webhook_xendit"
export PRICE_COINS_500_IDR=15000
export PRICE_COINS_1500_IDR=40000
export PRICE_COINS_5000_IDR=120000
export PRICE_UNLIMITED_30D_IDR=50000
node server.js
```

Harga di atas hanya contoh untuk pengujian/konfigurasi; tentukan harga jual sendiri sebelum live. Harga USD juga wajib ditetapkan melalui PRICE_*_USD agar tombol Stripe aktif.

## Setup Xendit (Indonesia)
1. Buat/aktifkan akun Xendit dan gunakan API key test untuk pengujian.
2. Aktifkan payment channels yang diinginkan di Dashboard (mis. QRIS, e-wallet yang tersedia untuk akun, virtual account, kartu).
3. Atur webhook Payment Session Completed dan Payment Session Expired di Dashboard ke `https://domain-aplikasi-kamu/api/webhooks/xendit`.
4. Salin callback verification token ke `XENDIT_CALLBACK_TOKEN` dan secret API key ke `XENDIT_SECRET_KEY`.
5. Uji invoice dan callback di test mode sebelum mengaktifkan live mode.

## Setup Stripe (internasional)
1. `STRIPE_SECRET_KEY` harus berasal dari akun Stripe yang sudah onboarded dan berhak menerima pembayaran internasional.
2. Atur endpoint webhook `https://domain-aplikasi-kamu/api/webhooks/stripe` untuk event `checkout.session.completed` dan `checkout.session.async_payment_succeeded`.
3. Simpan signing secret webhook ke `STRIPE_WEBHOOK_SECRET`.
4. Set harga USD untuk setiap paket. Checkout dibuat sebagai pembayaran satu kali; Unlimited tidak memakai subscription/recurring.

PENTING: dokumentasi Stripe saat ini menyatakan akun Stripe berbasis Indonesia hanya menerima IDR melalui virtual account dan tidak mendukung transaksi lintas negara. Program onboarding Stripe Indonesia juga invite-only. Karena itu, tombol Stripe internasional hanya akan aktif bila kamu memiliki akun Stripe di negara yang didukung dan secara sah memenuhi persyaratan Stripe. Jangan memakai alamat atau badan usaha fiktif. Jika belum punya akun Stripe yang eligible, gunakan Xendit untuk transaksi IDR dan tunda Stripe sampai onboarding legal tersedia.

## Keamanan dan operasional
- Gunakan HTTPS untuk produksi dan `APP_BASE_URL` harus URL publik yang sama dengan domain checkout.
- Jangan mengirim API key ke frontend. Webhook Xendit diverifikasi dengan `X-CALLBACK-TOKEN`; Stripe diverifikasi dengan signature HMAC dan batas waktu.
- Aktifkan channel Xendit yang diinginkan pada dashboard. Ketersediaan GoPay/ShopeePay dan metode lain bergantung pada aktivasi serta kelayakan akun/merchant.
- Pastikan callback/webhook bisa diakses publik. Jangan menambahkan login/session middleware pada endpoint webhook.
- `wallet.json` menyimpan saldo dan daftar order yang sudah diproses untuk mencegah kredit ganda.
- Jangan hapus folder `data`, `story`, atau `auth` saat deploy jika ingin mempertahankan data.
- RUNPOD_KEY yang pernah tertulis langsung di source file lama harus di-rotate/revoke; gunakan key baru dari environment.
- Untuk tes lokal saja, set `INITIAL_COINS=300`; jangan gunakan saldo awal gratis ini di produksi.
